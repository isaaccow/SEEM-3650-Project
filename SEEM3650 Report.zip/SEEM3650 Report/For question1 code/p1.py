import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

# 从Excel文件读取数据
data = pd.read_excel('data.xlsx')

# 提取与温室气体排放和温度测量相关的列
emissions = data['Total GHG Emissions']
temperature = data['Average Temperature']

# 将数据转换为 numpy 数组，并重新调整形状以适应线性回归模型
X = emissions.values.reshape(-1, 1)
y = temperature.values

# 创建线性回归模型
model = LinearRegression()

# 将模型拟合到数据
model.fit(X, y)

# 使用线性回归模型进行预测
y_pred = model.predict(X)

# 计算决定系数（R-squared）作为性能指标
r2 = r2_score(y, y_pred)

# 绘制数据和线性回归线
plt.scatter(X, y, color='blue', label='Actual Data')
plt.plot(X, y_pred, color='red', label='Linear Regression')
plt.xlabel('Total GHG Emissions')
plt.ylabel('Average Temperature')
plt.title('Relationship between GHG Emissions and Temperature')
plt.legend()
plt.show()

print(f"Coefficient of Determination (R-squared): {r2}")